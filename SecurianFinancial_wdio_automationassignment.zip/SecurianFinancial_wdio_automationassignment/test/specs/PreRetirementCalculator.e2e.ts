import RetirementCalculatorPage from "../pageobjects/PreRetirementCalculator.page.js";
import appData from "../TestData/TestData.json" assert { type: "json" };

describe("Pre-retirement calculator", () => {
  beforeEach(async () => {
    await RetirementCalculatorPage.open();
    await browser.maximizeWindow();
    expect(await browser.getTitle()).toEqual(
      appData.staticmessages.planhomepagetitle
    );
  });

  it("User should be able to submit form with all fields filled in", async () => {
    await RetirementCalculatorPage.enterCurrentAge(
      appData.retirementplandata.currentage
    );

    await RetirementCalculatorPage.enterRetirementAge(
      appData.retirementplandata.retirementage
    );

    await RetirementCalculatorPage.enterCurrentAnnualIncome(
      appData.retirementplandata.annualincome
    );

    await RetirementCalculatorPage.enterSpouseAnnualIncome(
      appData.retirementplandata.spouseincome
    );

    await RetirementCalculatorPage.enterRetirementCurrentSavings(
      appData.retirementplandata.currentsavingsbalance
    );

    await RetirementCalculatorPage.enterYearlySavingsRate(
      appData.retirementplandata.yearlysavings
    );

    await RetirementCalculatorPage.enterYearlySavingsIncrementRate(
      appData.retirementplandata.yearlyincrementrate
    );

    await RetirementCalculatorPage.btnCalculatePlan.click();

    await (
      await RetirementCalculatorPage.labelResultsMessage
    ).waitForDisplayed({ timeout: 15000 });

    browser.pause(3000);

    await browser.execute(() => {
      window.scrollTo(0, 0);
    });

    await browser.saveScreenshot(
      `./test/screenshots/${appData.screenshotnames.formsubmissionwithallfields}.png`
    );

    expect(await RetirementCalculatorPage.labelResultsMessage).toBeExisting();
  });

  it("User should be able to submit form with all required fields filled in", async () => {
    await RetirementCalculatorPage.enterCurrentAge(
      appData.retirementplandata.currentage
    );

    await RetirementCalculatorPage.enterRetirementAge(
      appData.retirementplandata.retirementage
    );

    await RetirementCalculatorPage.enterCurrentAnnualIncome(
      appData.retirementplandata.annualincome
    );
    /* Spouse income is vomited as it is not required field
    await RetirementCalculatorPage.enterSpouseAnnualIncome(
      appData.retirementplandata.spouseincome
    );
*/
    await RetirementCalculatorPage.enterRetirementCurrentSavings(
      appData.retirementplandata.currentsavingsbalance
    );

    await RetirementCalculatorPage.enterYearlySavingsRate(
      appData.retirementplandata.yearlysavings
    );

    await RetirementCalculatorPage.enterYearlySavingsIncrementRate(
      appData.retirementplandata.yearlyincrementrate
    );

    browser.pause(1000);

    await browser.saveScreenshot(
      `./test/screenshots/${appData.screenshotnames.nonrequiredfield}.png`
    );

    await RetirementCalculatorPage.btnCalculatePlan.click();

    await (
      await RetirementCalculatorPage.labelResultsMessage
    ).waitForDisplayed({ timeout: 15000 });

    browser.pause(3000);

    await browser.execute(() => {
      window.scrollTo(0, 0);
    });

    await browser.saveScreenshot(
      `./test/screenshots/${appData.screenshotnames.formsubmissionwithrequiredfields}.png`
    );

    expect(await RetirementCalculatorPage.labelResultsMessage).toBeExisting();
  });

  it("Additional Social Security fields should display/hide based on Social Security benefits toggle", async () => {
    await RetirementCalculatorPage.enterCurrentAge(
      appData.retirementplandata.currentage
    );

    await RetirementCalculatorPage.enterRetirementAge(
      appData.retirementplandata.retirementage
    );

    await RetirementCalculatorPage.enterCurrentAnnualIncome(
      appData.retirementplandata.annualincome
    );
    /* Spouse income is vomited as it is not required field
    await RetirementCalculatorPage.enterSpouseAnnualIncome(
      appData.retirementplandata.spouseincome
    );
*/
    await RetirementCalculatorPage.enterRetirementCurrentSavings(
      appData.retirementplandata.currentsavingsbalance
    );

    await RetirementCalculatorPage.enterYearlySavingsRate(
      appData.retirementplandata.yearlysavings
    );

    await RetirementCalculatorPage.enterYearlySavingsIncrementRate(
      appData.retirementplandata.yearlyincrementrate
    );

    await RetirementCalculatorPage.selectSocialSecurityIncome(true);
    expect(RetirementCalculatorPage.inputSingleMaritalStatus).toBeExisting();
    expect(RetirementCalculatorPage.inputMarriedMaritalStatus).toBeExisting();
    expect(RetirementCalculatorPage.enterSecurityOverrideAmount).toBeExisting();

    await (
      await RetirementCalculatorPage.inputMarriedMaritalStatus
    ).waitForClickable();
    (await RetirementCalculatorPage.inputMarriedMaritalStatus).click();
    await RetirementCalculatorPage.enterSecurityOverrideAmount(
      appData.retirementplandata.securityoverrideamount
    );

    await browser.saveScreenshot(
      `./test/screenshots/${appData.screenshotnames.socialsecurityadditionalfileds}.png`
    );

    await RetirementCalculatorPage.btnCalculatePlan.click();

    await (
      await RetirementCalculatorPage.labelResultsMessage
    ).waitForDisplayed({ timeout: 15000 });

    browser.pause(3000);

    await browser.execute(() => {
      window.scrollTo(0, 0);
    });

    await browser.saveScreenshot(
      `./test/screenshots/${appData.screenshotnames.fromsubmissionwithsociasecurityfields}.png`
    );

    expect(await RetirementCalculatorPage.labelResultsMessage).toBeExisting();
  });

  it("User should be able to update default calculator values", async () => {
    await RetirementCalculatorPage.enterCurrentAge(
      appData.retirementplandata.currentage
    );

    await RetirementCalculatorPage.enterRetirementAge(
      appData.retirementplandata.retirementage
    );

    await RetirementCalculatorPage.enterCurrentAnnualIncome(
      appData.retirementplandata.annualincome
    );

    await RetirementCalculatorPage.enterRetirementCurrentSavings(
      appData.retirementplandata.currentsavingsbalance
    );

    await RetirementCalculatorPage.enterYearlySavingsRate(
      appData.retirementplandata.yearlysavings
    );

    await RetirementCalculatorPage.enterYearlySavingsIncrementRate(
      appData.retirementplandata.yearlyincrementrate
    );

    (await RetirementCalculatorPage.linkAdjustDefaultValues).click();

    await RetirementCalculatorPage.enterAdditionalIncome(
      appData.retirementplandata.additionalincome
    );

    await RetirementCalculatorPage.enterRetirementDuration(
      appData.retirementplandata.retirementduration
    );

    await RetirementCalculatorPage.enterEveryYearAnnualIncomeForRetirement(
      appData.retirementplandata.desiredfinalincome
    );

    await RetirementCalculatorPage.enterPreretirementInvestmentReturn(
      appData.retirementplandata.preinvestmentreturn
    );

    await RetirementCalculatorPage.enterPostretirementInvestmentReturn(
      appData.retirementplandata.postinvestmentreturn
    );

    await browser.saveScreenshot(
      `./test/screenshots/${appData.screenshotnames.modifieddefaultvalues}.png`
    );

    (await RetirementCalculatorPage.saveDefaultValues).click();

    await RetirementCalculatorPage.btnCalculatePlan.click();

    await (
      await RetirementCalculatorPage.labelResultsMessage
    ).waitForDisplayed({ timeout: 15000 });

    browser.pause(3000);

    await browser.execute(() => {
      window.scrollTo(0, 0);
    });

    await browser.saveScreenshot(
      `./test/screenshots/${appData.screenshotnames.formsubmissionwithdefaultvaluesmodified}.png`
    );

    expect(await RetirementCalculatorPage.labelResultsMessage).toBeExisting();
  });
});
